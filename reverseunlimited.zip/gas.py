from concurrent.futures import ThreadPoolExecutor, as_completed
from bs4 import BeautifulSoup
import requests, socket, re, random, time

URL = 'http://www.threatcrowd.org/searchApi/v2/ip/report/'
REGEX = r = re.compile('([\w\d.-]+\.[\w\.]{2,6})')
LIST_USER_AGENTS = [_.rstrip() for _ in open('user-agents.txt','r').readlines()]



class ReverseIp:
    def __init__(self, web_list='', threads=10, output='results.txt', site=''):
        self.web_list = web_list
        self.site = site 
        self.threads = threads
        self.output = output
    
    def start(self):
        try:
            print('Starting the threads ...')
            with ThreadPoolExecutor(max_workers=self.threads) as eksekutor:
                site_list = set([self.cleaner(_.rstrip()) for _ in open(self.web_list,'r').readlines()])
                masa_lalu = []
                for url in site_list:
                    masa_lalu.append(eksekutor.submit(self.fucking_site, url))
                    time.sleep(0.001)
                for masa_depan in as_completed(masa_lalu):
                    print(masa_depan.result())
                
        except Exception as e:
            print(e)
    
    def fucking_site(self, site: str) -> any:
        try:
            hostname = socket.gethostbyname(site)
            response = requests.get('http://www.threatcrowd.org/searchApi/v2/ip/report/',{'ip':hostname}, headers={'User-Agent':random.choice(LIST_USER_AGENTS)})
            if 'resolutions' in response.text:
                json_result = response.json()['resolutions']
                list_web = [x['domain'] for x in json_result]
                open('results.txt','a').write('\n'.join(list_web))
                return f'{site} {len(list_web)}'
        except Exception as e:
            return e, site
    
    def cleaner(self, site: str) -> str:
        return REGEX.findall(site)[0]

def main():
    web_list = input('Web List : ')
    threads = int(input('Threads : '))
    r = ReverseIp(web_list=web_list, threads=threads)
    r.start()

if __name__ == "__main__":
    main()
